
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    MedicineViewSet,
    PharmacyViewSet,
    PriceListingViewSet,
)

router = DefaultRouter()
router.register("medicines", MedicineViewSet)
router.register("pharmacies", PharmacyViewSet)
router.register("prices", PriceListingViewSet)

urlpatterns = [
    path("", include(router.urls)),
]


from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    MedicineViewSet,
    PharmacyViewSet,
    PriceListingViewSet,
    LiveMedicineComparisonView,
)

router = DefaultRouter()
router.register("medicines", MedicineViewSet)
router.register("pharmacies", PharmacyViewSet)
router.register("prices", PriceListingViewSet)

urlpatterns = [
    path("", include(router.urls)),
    path(
        "compare-live/",
        LiveMedicineComparisonView.as_view(),
        name="compare-live",
    ),
]
