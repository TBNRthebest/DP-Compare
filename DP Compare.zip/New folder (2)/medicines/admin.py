
from django.contrib import admin
from .models import Medicine, Pharmacy, PriceListing

admin.site.register(Medicine)
admin.site.register(Pharmacy)
admin.site.register(PriceListing)
