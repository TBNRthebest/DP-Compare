
from django.db import models


class Medicine(models.Model):
    name = models.CharField(max_length=200)
    brand = models.CharField(max_length=150)
    active_ingredient = models.CharField(max_length=200)
    strength = models.CharField(max_length=100)
    form = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.name} - {self.strength}"


class Pharmacy(models.Model):
    name = models.CharField(max_length=200)
    address = models.CharField(max_length=300)
    city = models.CharField(max_length=100)
    website = models.URLField(blank=True)

    def __str__(self):
        return self.name


class PriceListing(models.Model):
    medicine = models.ForeignKey(
        Medicine,
        on_delete=models.CASCADE,
        related_name="price_listings"
    )
    pharmacy = models.ForeignKey(
        Pharmacy,
        on_delete=models.CASCADE,
        related_name="price_listings"
    )
    price = models.DecimalField(max_digits=10, decimal_places=2)
    product_url = models.URLField(blank=True, default="")
    in_stock = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.medicine} - ₹{self.price}"