from django.shortcuts import render


from rest_framework import viewsets
from .models import Medicine, Pharmacy, PriceListing
from .serializers import (
    MedicineSerializer,
    PharmacySerializer,
    PriceListingSerializer,
)


class MedicineViewSet(viewsets.ModelViewSet):
    queryset = Medicine.objects.all().order_by("name")
    serializer_class = MedicineSerializer
    search_fields = ["name", "brand", "active_ingredient"]
    filterset_fields = ["brand", "form", "strength"]


class PharmacyViewSet(viewsets.ModelViewSet):
    queryset = Pharmacy.objects.all().order_by("name")
    serializer_class = PharmacySerializer
    search_fields = ["name", "city"]


class PriceListingViewSet(viewsets.ModelViewSet):
    queryset = PriceListing.objects.select_related(
        "medicine", "pharmacy"
    ).all().order_by("price")
    serializer_class = PriceListingSerializer
    filterset_fields = ["medicine", "pharmacy", "in_stock"]
    search_fields = [
        "medicine__name",
        "medicine__brand",
        "medicine__active_ingredient",
        "pharmacy__name",
        "pharmacy__city",
    ]
    ordering_fields = ["price", "updated_at"]


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .provider_integrations import compare_prices


class LiveMedicineComparisonView(APIView):
    def get(self, request):
        query = request.query_params.get("q", "").strip()

        if not query:
            return Response(
                {"error": "Provide a medicine name using ?q="},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if len(query) > 120:
            return Response(
                {"error": "Search query must be 120 characters or fewer."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        data = compare_prices(query)
        return Response(data)