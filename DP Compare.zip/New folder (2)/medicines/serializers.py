
from rest_framework import serializers
from .models import Medicine, Pharmacy, PriceListing


class MedicineSerializer(serializers.ModelSerializer):
    class Meta:
        model = Medicine
        fields = "__all__"


class PharmacySerializer(serializers.ModelSerializer):
    class Meta:
        model = Pharmacy
        fields = "__all__"


class PriceListingSerializer(serializers.ModelSerializer):
    medicine_name = serializers.CharField(
        source="medicine.name",
        read_only=True
    )
    pharmacy_name = serializers.CharField(
        source="pharmacy.name",
        read_only=True
    )
    pharmacy_city = serializers.CharField(
        source="pharmacy.city",
        read_only=True
    )

    class Meta:
        model = PriceListing
        fields = [
            "id",
            "medicine",
            "medicine_name",
            "pharmacy",
            "pharmacy_name",
            "pharmacy_city",
            "price",
            "in_stock",
            "updated_at",
        ]
