
import os
import requests

from decimal import Decimal, InvalidOperation
from urllib.parse import urlparse


# These are configuration names, NOT real pharmacy API endpoints.
PROVIDERS = {
    "tata1mg": {
        "name": "Tata 1mg",
        "url_env": "TATA1MG_API_URL",
        "key_env": "TATA1MG_API_KEY",
    },
    "pharmeasy": {
        "name": "PharmEasy",
        "url_env": "PHARMEASY_API_URL",
        "key_env": "PHARMEASY_API_KEY",
    },
    "netmeds": {
        "name": "Netmeds",
        "url_env": "NETMEDS_API_URL",
        "key_env": "NETMEDS_API_KEY",
    },
}


def search_provider(provider_id, query):
    provider = PROVIDERS[provider_id]

    api_url = os.environ.get(provider["url_env"])
    api_key = os.environ.get(provider["key_env"])

    if not api_url or not api_key:
        return {
            "provider": provider["name"],
            "status": "not_configured",
            "results": [],
        }

    parsed_url = urlparse(api_url)

    # Require HTTPS for external API requests.
    if parsed_url.scheme != "https" or not parsed_url.hostname:
        return {
            "provider": provider["name"],
            "status": "invalid_configuration",
            "results": [],
        }

    try:
        response = requests.get(
            api_url,
            params={"q": query},
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()

    except (requests.RequestException, ValueError):
        return {
            "provider": provider["name"],
            "status": "provider_unavailable",
            "results": [],
        }

    if not isinstance(payload, dict):
        return {
            "provider": provider["name"],
            "status": "invalid_response",
            "results": [],
        }

    items = payload.get("results", [])
    if not isinstance(items, list):
        items = []

    results = []

    for item in items:
        if not isinstance(item, dict):
            continue

        try:
            price = Decimal(str(item["price"]))
        except (KeyError, InvalidOperation, ValueError):
            continue

        if not price.is_finite() or price < 0:
            continue

        product_url = item.get("product_url", "")

        # Only accept HTTPS product links.
        if not isinstance(product_url, str):
            continue

        link = urlparse(product_url)
        if link.scheme != "https" or not link.hostname:
            continue

        results.append({
            "provider": provider["name"],
            "medicine_name": item.get("name", ""),
            "brand": item.get("brand", ""),
            "ingredient": item.get("ingredient", ""),
            "strength": item.get("strength", ""),
            "form": item.get("form", ""),
            "pack_size": item.get("pack_size", ""),
            "price": str(price),
            "currency": item.get("currency", "INR"),
            "in_stock": item.get("in_stock") is True,
            "product_url": product_url,
            "source_status": "provider_response",
        })

    return {
        "provider": provider["name"],
        "status": "ok",
        "results": results,
    }


def compare_prices(query):
    all_results = []
    provider_status = []

    for provider_id in PROVIDERS:
        response = search_provider(provider_id, query)

        provider_status.append({
            "provider": response["provider"],
            "status": response["status"],
        })

        all_results.extend(response["results"])

    # Sorting is useful, but it does not prove that
    # the products have identical ingredients or pack sizes.
    all_results.sort(key=lambda item: Decimal(item["price"]))

    return {
        "query": query,
        "results": all_results,
        "providers": provider_status,
    }
