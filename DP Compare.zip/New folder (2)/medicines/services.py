
import os
import requests
from decimal import Decimal, InvalidOperation


def fetch_pharmacy_prices(api_url, query):
    api_key = os.environ.get("PHARMACY_API_KEY")

    if not api_key:
        raise ValueError("Missing pharmacy API key")

    response = requests.get(
        api_url,
        params={"q": query},
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=15,
    )
    response.raise_for_status()

    data = response.json()
    results = []

    for item in data.get("results", []):
        try:
            price = Decimal(str(item["price"]))
        except (KeyError, InvalidOperation, ValueError):
            continue

        if price < 0:
            continue

        results.append({
            "name": item.get("name", ""),
            "price": price,
            "url": item.get("product_url", ""),
            "in_stock": item.get("in_stock", False),
            "source": item.get("source", ""),
        })

    return sorted(results, key=lambda item: item["price"])
